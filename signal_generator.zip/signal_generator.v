module signal_generator (
    input wire clk,
    input wire reset,
    input wire enable,

    input wire [1:0] pattern_sel,
    input wire [3:0] external_signal,

    output reg [3:0] signal_out
);

    reg [7:0] counter;

    // Counter: tao bo dem de sinh tin hieu
    always @(posedge clk or posedge reset) begin
        if (reset)
            counter <= 8'd0;
        else if (enable)
            counter <= counter + 1'b1;
    end

    // Lua chon dang tin hieu dau ra
    always @(*) begin
        case (pattern_sel)

            // Pattern 00: Ca 4 kenh cung dao trang thai
            2'b00:
                signal_out = {4{counter[0]}};

            // Pattern 01: 4 kenh co tan so khac nhau
            2'b01:
                signal_out = {
                    counter[3],
                    counter[2],
                    counter[1],
                    counter[0]
                };

            // Pattern 10: Tin hieu di chuyen tung kenh
            2'b10:
                signal_out = 4'b0001 << counter[1:0];

            // Pattern 11: Su dung tin hieu ngoai
            2'b11:
                signal_out = external_signal;

            default:
                signal_out = 4'b0000;

        endcase
    end

endmodule
