`timescale 1ns/1ps
module tb_cache_controller;

    reg        clk, rst;
    reg        cpu_rd, cpu_wr;
    reg  [7:0] cpu_addr, cpu_wr_data;
    wire [7:0] cpu_rd_data;
    wire       cpu_ready, cache_hit, cache_miss;

    wire [5:0] tag   = cpu_addr[7:2];      // Address Decoder (gia lap)
    wire [1:0] index = cpu_addr[1:0];

    wire [1:0] tag_index, data_index;
    wire [5:0] tag_in, tag_out;
    wire       valid_in, valid_out, tag_we;
    wire [7:0] cache_data_in, cache_data_out;
    wire       data_we;
    wire [7:0] mem_addr, mem_wr_data, mem_rd_data;
    wire       mem_rd, mem_wr, mem_ready;

    cache_controller dut (
        .clk(clk), .rst(rst),
        .cpu_rd(cpu_rd), .cpu_wr(cpu_wr), .cpu_addr(cpu_addr), .cpu_wr_data(cpu_wr_data),
        .cpu_rd_data(cpu_rd_data), .cpu_ready(cpu_ready),
        .cache_hit(cache_hit), .cache_miss(cache_miss),
        .tag(tag), .index(index),
        .tag_index(tag_index), .tag_in(tag_in), .valid_in(valid_in), .tag_we(tag_we),
        .tag_out(tag_out), .valid_out(valid_out),
        .data_index(data_index), .cache_data_in(cache_data_in), .data_we(data_we),
        .cache_data_out(cache_data_out),
        .mem_addr(mem_addr), .mem_rd(mem_rd), .mem_wr(mem_wr), .mem_wr_data(mem_wr_data),
        .mem_rd_data(mem_rd_data), .mem_ready(mem_ready)
    );

    // Nguoi 4: Data Array that
    cache_data_array u_data (
        .clk(clk), .rst(rst), .data_index(data_index),
        .cache_data_in(cache_data_in), .data_we(data_we),
        .cache_data_out(cache_data_out)
    );

    // ---- Mo hinh tam thoi cho Tag/Valid Array (thay bang module that cua nhom) ----
    reg [5:0] tag_mem [0:3];
    reg [3:0] valid_mem;
    integer   j;
    always @(posedge clk) begin
        if (rst) valid_mem <= 4'b0000;
        else if (tag_we) begin
            tag_mem[tag_index]   <= tag_in;
            valid_mem[tag_index] <= valid_in;
        end
    end
    assign tag_out   = tag_mem[tag_index];
    assign valid_out = valid_mem[tag_index];

    // ---- Mo hinh tam thoi cho Main Memory, tre 3 clock (thay bang module that) ----
    reg [7:0] main_mem [0:255];
    reg [7:0] mem_rd_data_r;
    reg       mem_ready_r;
    reg [1:0] lat_cnt;
    assign mem_rd_data = mem_rd_data_r;
    assign mem_ready   = mem_ready_r;
    always @(posedge clk) begin
        if (rst) begin
            lat_cnt <= 0; mem_ready_r <= 0;
        end else begin
            mem_ready_r <= 0;
            if ((mem_rd || mem_wr) && !mem_ready_r) begin
                if (lat_cnt == 2) begin
                    lat_cnt <= 0;
                    mem_ready_r <= 1;
                    if (mem_wr) main_mem[mem_addr] <= mem_wr_data;
                    mem_rd_data_r <= main_mem[mem_addr];
                end else lat_cnt <= lat_cnt + 1;
            end
        end
    end

    // Dem so giao dich RAM chinh
    integer rd_txn, wr_txn;
    always @(posedge clk) begin
        if (mem_ready_r && mem_rd) rd_txn = rd_txn + 1;
        if (mem_ready_r && mem_wr) wr_txn = wr_txn + 1;
    end

    initial begin clk = 0; forever #5 clk = ~clk; end

    // ---- Task truy cap CPU: giu yeu cau den khi cpu_ready ----
    reg [7:0] got_data;
    reg       got_hit, got_miss;
    task cpu_access;
        input       is_wr;
        input [7:0] addr;
        input [7:0] data;
        begin
            @(negedge clk);
            cpu_addr = addr; cpu_wr_data = data;
            cpu_rd = !is_wr; cpu_wr = is_wr;
            @(negedge clk);
            while (cpu_ready !== 1'b1) @(negedge clk);   // cho den chu ky RESP
            got_data = cpu_rd_data; got_hit = cache_hit; got_miss = cache_miss;
            cpu_rd = 0; cpu_wr = 0;
        end
    endtask

    integer test_num, errors;
    task check;
        input       cond;
        input [511:0] name;
        begin
            test_num = test_num + 1;
            if (cond) $display("TEST %0d PASS: %0s", test_num, name);
            else begin
                $display("TEST %0d FAIL: %0s (data=%h hit=%b miss=%b)",
                         test_num, name, got_data, got_hit, got_miss);
                errors = errors + 1;
            end
        end
    endtask

    integer n;
    initial begin
        test_num = 0; errors = 0; rd_txn = 0; wr_txn = 0;
        cpu_rd = 0; cpu_wr = 0; cpu_addr = 0; cpu_wr_data = 0;
        for (n = 0; n < 256; n = n + 1) main_mem[n] = n[7:0] ^ 8'hA5;
        rst = 1;
        $display("--------------------------------");
        $display(" CACHE CONTROLLER TEST START");
        $display("--------------------------------");
        repeat (3) @(negedge clk);
        rst = 0;
        check(cpu_ready === 0 && mem_rd === 0 && mem_wr === 0, "sau reset: IDLE, khong truy cap RAM");

        // 1. Read miss (cache rong)
        cpu_access(0, 8'h10, 0);
        check(got_miss && !got_hit, "read 0x10 lan 1: MISS");
        check(got_data === (8'h10 ^ 8'hA5), "read miss tra dung du lieu tu RAM chinh");
        check(rd_txn == 1, "read miss: doc RAM chinh 1 lan");

        // 2. Read hit
        cpu_access(0, 8'h10, 0);
        check(got_hit && !got_miss, "read 0x10 lan 2: HIT");
        check(got_data === (8'h10 ^ 8'hA5), "read hit tra dung du lieu");
        check(rd_txn == 1, "read hit: KHONG doc RAM chinh");

        // 3. Conflict: 0x14 cung index 0 voi 0x10 nhung khac tag
        cpu_access(0, 8'h14, 0);
        check(got_miss, "read 0x14 (cung index, khac tag): MISS");
        check(got_data === (8'h14 ^ 8'hA5), "du lieu 0x14 dung");
        cpu_access(0, 8'h10, 0);
        check(got_miss, "read lai 0x10: MISS (bi 0x14 ghi de)");

        // 4. 4 line khac nhau cung ton tai
        cpu_access(0, 8'h21, 0);
        cpu_access(0, 8'h32, 0);
        cpu_access(0, 8'h43, 0);
        cpu_access(0, 8'h21, 0); check(got_hit && got_data === (8'h21 ^ 8'hA5), "0x21 HIT");
        cpu_access(0, 8'h32, 0); check(got_hit && got_data === (8'h32 ^ 8'hA5), "0x32 HIT");
        cpu_access(0, 8'h43, 0); check(got_hit && got_data === (8'h43 ^ 8'hA5), "0x43 HIT");

        // 5. Write hit (write-through): cache va RAM chinh deu duoc cap nhat
        wr_txn = 0;
        cpu_access(1, 8'h21, 8'h55);
        check(got_hit, "write 0x21: HIT");
        check(wr_txn == 1 && main_mem[8'h21] === 8'h55, "write-through: RAM chinh = 55");
        cpu_access(0, 8'h21, 0);
        check(got_hit && got_data === 8'h55, "doc lai 0x21 = 55 (cache da cap nhat)");

        // 6. Write miss (no-write-allocate): chi ghi RAM chinh, khong nap vao cache
        wr_txn = 0; rd_txn = 0;
        cpu_access(1, 8'h2B, 8'h77);                 // index 3, tag khac 0x43
        check(got_miss, "write 0x2B: MISS");
        check(wr_txn == 1 && main_mem[8'h2B] === 8'h77, "write miss: RAM chinh = 77");
        cpu_access(0, 8'h43, 0);
        check(got_hit && got_data === (8'h43 ^ 8'hA5), "no-write-allocate: line cu 0x43 van con");
        cpu_access(0, 8'h2B, 0);
        check(got_miss && got_data === 8'h77, "doc 0x2B: MISS, lay 77 tu RAM chinh");

        // 7. Reset xoa valid
        rst = 1; @(negedge clk); @(negedge clk); rst = 0;
        cpu_access(0, 8'h21, 0);
        check(got_miss, "sau reset: 0x21 MISS (valid da bi xoa)");

        $display("--------------------------------");
        if (errors == 0) $display(" ALL %0d TESTS PASSED!", test_num);
        else             $display(" %0d / %0d TESTS FAILED", errors, test_num);
        $display("--------------------------------");
        $finish;
    end

    initial begin #20000; $display("TIMEOUT"); $finish; end
endmodule