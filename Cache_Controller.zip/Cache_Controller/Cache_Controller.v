`timescale 1ns/1ps
module cache_controller (
    input  wire       clk,
    input  wire       rst,

    // CPU interface
    input  wire       cpu_rd,
    input  wire       cpu_wr,
    input  wire [7:0] cpu_addr,
    input  wire [7:0] cpu_wr_data,
    output wire [7:0] cpu_rd_data,
    output wire       cpu_ready,
    output wire       cache_hit,
    output wire       cache_miss,

    // Address Decoder
    input  wire [5:0] tag,
    input  wire [1:0] index,

    // Tag/Valid Array
    output wire [1:0] tag_index,
    output wire [5:0] tag_in,
    output wire       valid_in,
    output wire       tag_we,
    input  wire [5:0] tag_out,
    input  wire       valid_out,

    // Cache Data Array
    output wire [1:0] data_index,
    output wire [7:0] cache_data_in,
    output wire       data_we,
    input  wire [7:0] cache_data_out,

    // Main Memory
    output wire [7:0] mem_addr,
    output wire       mem_rd,
    output wire       mem_wr,
    output wire [7:0] mem_wr_data,
    input  wire [7:0] mem_rd_data,
    input  wire       mem_ready
);

//----------Trang Thai------------
    localparam [2:0] IDLE    = 3'd0,
                     COMPARE = 3'd1,
                     MEM_RD  = 3'd2,   // doc RAM chinh (read miss)
                     REFILL  = 3'd3,   // ghi data+tag+valid vao cache
                     MEM_WR  = 3'd4,   // ghi RAM chinh (write-through)
                     RESP    = 3'd5;   // tra loi CPU
 
    reg [2:0] state, next_state;
    reg       hit_r;          // luu ket qua hit/miss de dung o RESP
    reg [7:0] refill_data;    // du lieu lay tu RAM chinh
 
    wire req = cpu_rd | cpu_wr;
    wire hit = valid_out && (tag_out == tag);
 
    // 1) Thanh ghi trang thai + cac thanh ghi phu
    always @(posedge clk) begin
        if (rst) begin
            state       <= IDLE;
            hit_r       <= 1'b0;
            refill_data <= 8'd0;
        end else begin
            state <= next_state;
            if (state == COMPARE)                hit_r       <= hit;
            if (state == MEM_RD && mem_ready)    refill_data <= mem_rd_data;
        end
    end
 
    // 2) Logic chuyen trang thai
    always @(*) begin
        next_state = state;
        case (state)
            IDLE:    if (req) next_state = COMPARE;
 
            COMPARE: if (cpu_wr)       next_state = MEM_WR;   // ghi: hit hay miss deu ghi RAM chinh
                     else if (hit)     next_state = RESP;     // doc hit
                     else              next_state = MEM_RD;   // doc miss
 
            MEM_RD:  if (mem_ready) next_state = REFILL;
            REFILL:                 next_state = RESP;
            MEM_WR:  if (mem_ready) next_state = RESP;
            RESP:                   next_state = IDLE;
            default:                next_state = IDLE;
        endcase
    end
 
    // 3) Output
    // Tag/Valid array
    assign tag_index = index;
    assign tag_in    = tag;
    assign valid_in  = 1'b1;
    assign tag_we    = (state == REFILL);
 
    // Data array
    assign data_index    = index;
    assign cache_data_in = (state == REFILL) ? refill_data : cpu_wr_data;
    assign data_we       = (state == REFILL) ||
                           (state == COMPARE && cpu_wr && hit);   // write hit
 
    // Main memory
    assign mem_addr    = cpu_addr;
    assign mem_rd      = (state == MEM_RD);
    assign mem_wr      = (state == MEM_WR);
    assign mem_wr_data = cpu_wr_data;
 
    // CPU
    assign cpu_rd_data = cache_data_out;
    assign cpu_ready   = (state == RESP);
    assign cache_hit   = (state == RESP) &&  hit_r;
    assign cache_miss  = (state == RESP) && !hit_r;
 
endmodule