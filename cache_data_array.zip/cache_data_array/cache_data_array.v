// Cache Data Array - Cache Memory Simulator RTL
// Cau hinh: Direct-Mapped, 4 Cache Lines, moi line 1 byte (8 bit)
// Quy uoc: rst ACTIVE-HIGH (khop voi cache_top), reset dong bo
// Ghi: dong bo theo clk khi data_we = 1
// Doc: to hop (combinational) theo data_index
module cache_data_array (
    input  wire       clk,
    input  wire       rst,

    input  wire [1:0] data_index,      // chon 1 trong 4 Cache Lines
    input  wire [7:0] cache_data_in,   // du lieu ghi (CPU ghi hoac refill)
    input  wire       data_we,         // cho phep ghi

    output wire [7:0] cache_data_out   // du lieu doc tu Cache
);

    reg [7:0] data_mem [0:3];
    integer i;

    // Ghi dong bo / reset xoa toan bo data ve 0 (tranh gia tri X khi mo phong)
    always @(posedge clk) begin
        if (rst) begin
            for (i = 0; i < 4; i = i + 1)
                data_mem[i] <= 8'd0;
        end
        else if (data_we) begin
            data_mem[data_index] <= cache_data_in;
        end
    end

    // Doc to hop
    assign cache_data_out = data_mem[data_index];

endmodule
