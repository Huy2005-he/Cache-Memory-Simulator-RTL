`timescale 1ns/1ps

module tb_cache_data_array;

    reg        clk;
    reg        rst;
    reg  [1:0] data_index;
    reg  [7:0] cache_data_in;
    reg        data_we;
    wire [7:0] cache_data_out;

    integer test_num;

    cache_data_array uut (
        .clk(clk),
        .rst(rst),
        .data_index(data_index),
        .cache_data_in(cache_data_in),
        .data_we(data_we),
        .cache_data_out(cache_data_out)
    );

    // Clock chu ky 10ns
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Task kiem tra dau ra
    task check_output;
        input [7:0] expected;
        begin
            #1;
            test_num = test_num + 1;
            if (cache_data_out === expected)
                $display("TEST %0d PASS: index = %0d, Output = %h",
                         test_num, data_index, cache_data_out);
            else begin
                $display("TEST %0d FAIL: index = %0d, Expected = %h, Got = %h",
                         test_num, data_index, expected, cache_data_out);
                $finish;
            end
        end
    endtask

    // Task ghi 1 line (tin hieu doi tai canh xuong, lay mau tai canh len)
    task write_line;
        input [1:0] idx;
        input [7:0] data;
        begin
            @(negedge clk);
            data_index    = idx;
            cache_data_in = data;
            data_we       = 1;
            @(negedge clk);
            data_we       = 0;
        end
    endtask

    integer k;

    initial begin
        test_num      = 0;
        rst           = 1;
        data_we       = 0;
        data_index    = 2'd0;
        cache_data_in = 8'h00;

        $display("--------------------------------");
        $display(" CACHE DATA ARRAY TEST START");
        $display("--------------------------------");

        // TEST 1: Reset - ca 4 line phai bang 0
        repeat (2) @(negedge clk);
        rst = 0;
        for (k = 0; k < 4; k = k + 1) begin
            data_index = k[1:0];
            check_output(8'h00);
        end
        $display("RESET TEST COMPLETED");

        // TEST 2: Ghi tung line roi doc lai
        write_line(2'd0, 8'hA1);
        write_line(2'd1, 8'hB2);
        write_line(2'd2, 8'hC3);
        write_line(2'd3, 8'hD4);

        data_index = 2'd0; check_output(8'hA1);
        data_index = 2'd1; check_output(8'hB2);
        data_index = 2'd2; check_output(8'hC3);
        data_index = 2'd3; check_output(8'hD4);
        $display("WRITE/READ TEST COMPLETED");

        // TEST 3: data_we = 0 thi khong ghi
        @(negedge clk);
        data_index    = 2'd1;
        cache_data_in = 8'hFF;
        data_we       = 0;
        @(negedge clk);
        check_output(8'hB2);
        $display("WRITE ENABLE TEST COMPLETED");

        // TEST 4: Ghi de 1 line khong anh huong line khac
        write_line(2'd2, 8'h5A);
        data_index = 2'd2; check_output(8'h5A);
        data_index = 2'd0; check_output(8'hA1);
        data_index = 2'd1; check_output(8'hB2);
        data_index = 2'd3; check_output(8'hD4);
        $display("OVERWRITE TEST COMPLETED");

        // TEST 5: Reset giua chung xoa het du lieu
        @(negedge clk);
        rst = 1;
        @(negedge clk);
        rst = 0;
        for (k = 0; k < 4; k = k + 1) begin
            data_index = k[1:0];
            check_output(8'h00);
        end
        $display("RESET CLEAR TEST COMPLETED");

        $display("--------------------------------");
        $display(" ALL TESTS PASSED!");
        $display("--------------------------------");

        #10;
        $finish;
    end

endmodule
