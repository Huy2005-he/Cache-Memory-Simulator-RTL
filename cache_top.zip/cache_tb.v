
`timescale 1ns/1ps

module cache_tb;

    // =================================
    // 1. TESTBENCH SIGNALS
    // =================================

    reg clk;
    reg rst_n;

    reg cpu_req;
    reg cpu_we;
    reg [7:0] cpu_addr;
    reg [7:0] cpu_wdata;

    wire [7:0] cpu_rdata;
    wire cpu_ready;
    wire cache_hit;
    wire cache_miss;

    integer hit_count;
    integer miss_count;
    integer error_count;


    // =================================
    // 2. CLOCK GENERATION
    // =================================

    initial clk = 0;

    always #5 clk = ~clk;


    // =================================
    // 3. CONNECT CACHE SYSTEM
    // =================================

    cache_top uut (

        .clk(clk),
        .rst_n(rst_n),

        .cpu_req(cpu_req),
        .cpu_we(cpu_we),
        .cpu_addr(cpu_addr),
        .cpu_wdata(cpu_wdata),

        .cpu_rdata(cpu_rdata),
        .cpu_ready(cpu_ready),

        .cache_hit(cache_hit),
        .cache_miss(cache_miss)
    );


    // =================================
    // 4. COUNT HIT AND MISS
    // =================================

    always @(posedge clk) begin

        if (!rst_n) begin
            hit_count = 0;
            miss_count = 0;
        end

        else begin

            if (cache_hit)
                hit_count = hit_count + 1;

            if (cache_miss)
                miss_count = miss_count + 1;

        end

    end


    // =================================
    // 5. CPU READ TASK
    // =================================

    task cpu_read;

        input [7:0] address;
        input [7:0] expected_data;

        integer timeout;

        begin

            @(negedge clk);

            cpu_addr = address;
            cpu_we = 0;
            cpu_req = 1;

            timeout = 0;

            while ((cpu_ready !== 1'b1) &&
                   (timeout < 50)) begin

                @(posedge clk);
                #1;

                timeout = timeout + 1;

            end

            if (cpu_ready !== 1'b1) begin

                $display("FAIL: READ TIMEOUT at %h",
                         address);

                error_count = error_count + 1;

            end

            else if (cpu_rdata !== expected_data) begin

                $display("FAIL: Address=%h Expected=%h Actual=%h",
                         address, expected_data, cpu_rdata);

                error_count = error_count + 1;

            end

            else begin

                $display("PASS: READ Address=%h Data=%h",
                         address, cpu_rdata);

            end

            @(negedge clk);

            cpu_req = 0;

            @(posedge clk);
            #1;

        end

    endtask


    // =================================
    // 6. CPU WRITE TASK
    // =================================

    task cpu_write;

        input [7:0] address;
        input [7:0] write_data;

        integer timeout;

        begin

            @(negedge clk);

            cpu_addr = address;
            cpu_wdata = write_data;
            cpu_we = 1;
            cpu_req = 1;

            timeout = 0;

            while ((cpu_ready !== 1'b1) &&
                   (timeout < 50)) begin

                @(posedge clk);
                #1;

                timeout = timeout + 1;

            end

            if (cpu_ready !== 1'b1) begin

                $display("FAIL: WRITE TIMEOUT at %h",
                         address);

                error_count = error_count + 1;

            end

            else begin

                $display("PASS: WRITE Address=%h Data=%h",
                         address, write_data);

            end

            @(negedge clk);

            cpu_req = 0;
            cpu_we = 0;

            @(posedge clk);
            #1;

        end

    endtask


    // =================================
    // 7. MAIN TEST SEQUENCE
    // =================================

    initial begin

        rst_n = 0;

        cpu_req = 0;
        cpu_we = 0;

        cpu_addr = 0;
        cpu_wdata = 0;

        error_count = 0;

        $display("--------------------------------");
        $display(" CACHE MEMORY SIMULATION START");
        $display("--------------------------------");

        // Reset
        repeat(3) @(posedge clk);

        #1 rst_n = 1;

        // TEST 1: First read - Cache Miss
        cpu_read(8'h10, 8'h10);

        // TEST 2: Second read - Cache Hit
        cpu_read(8'h10, 8'h10);

        // TEST 3: Read second word in same block
        cpu_read(8'h11, 8'h11);

        // TEST 4: Write data
        cpu_write(8'h10, 8'hA5);

        // TEST 5: Read written data
        cpu_read(8'h10, 8'hA5);

        // Final Results
        $display("--------------------------------");
        $display(" SIMULATION RESULTS");
        $display("--------------------------------");

        $display("Cache Hit  : %0d", hit_count);
        $display("Cache Miss : %0d", miss_count);
        $display("Errors     : %0d", error_count);

        if (error_count == 0 &&
            hit_count >= 3 &&
            miss_count >= 1) begin

            $display("OVERALL RESULT: PASS");

        end

        else begin

            $display("OVERALL RESULT: FAIL");

        end

        $display("--------------------------------");

        #20;
        $stop;

    end

endmodule
