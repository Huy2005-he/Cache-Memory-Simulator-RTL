// Trigger Detector for Cache Memory Simulator RTL
// Default address width is 8 bits to match cache_top CPU address.
// Reset convention: rst_n is ACTIVE-LOW (assert low to reset).
// If the parent Cache Top reset is active-high (rst), connect .rst_n(~rst).
module trigger_detector #(
    parameter integer ADDR_WIDTH = 8
)(
    input logic clk,
    input logic rst_n,
    input logic arm,

    input logic trigger_signal,
    input logic req_valid,
    input logic cache_hit,
    input logic cache_miss,

    // Both address ports use the same configurable width.
    // For this project: ADDR_WIDTH = 8.
    input logic [ADDR_WIDTH-1:0] cpu_addr,
    input logic [ADDR_WIDTH-1:0] trigger_addr,
    input logic [2:0] mode,

    output logic capture_start,
    output logic triggered
);

    localparam MODE_RISE       = 3'b000;
    localparam MODE_FALL       = 3'b001;
    localparam MODE_HIGH       = 3'b010;
    localparam MODE_LOW        = 3'b011;
    localparam MODE_ADDR_EQ    = 3'b100;
    localparam MODE_CACHE_MISS = 3'b101;
    localparam MODE_CACHE_HIT  = 3'b110;
    localparam MODE_ADDR_NE    = 3'b111;

    logic prev_signal;
    logic sample_valid;
    logic condition_met;

    always_comb begin
        condition_met = 1'b0;

        case (mode)

            MODE_RISE: begin
                condition_met =
                    sample_valid &&
                    trigger_signal &&
                    !prev_signal;
            end

            MODE_FALL: begin
                condition_met =
                    sample_valid &&
                    !trigger_signal &&
                    prev_signal;
            end

            MODE_HIGH: begin
                condition_met = trigger_signal;
            end

            MODE_LOW: begin
                condition_met = !trigger_signal;
            end

            MODE_ADDR_EQ: begin
                condition_met =
                    req_valid &&
                    (cpu_addr == trigger_addr);
            end

            MODE_CACHE_MISS: begin
                condition_met = req_valid && cache_miss;
            end

            MODE_CACHE_HIT: begin
                condition_met = req_valid && cache_hit;
            end

            MODE_ADDR_NE: begin
                condition_met =
                    req_valid &&
                    (cpu_addr != trigger_addr);
            end

            default: begin
                condition_met = 1'b0;
            end

        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            prev_signal   <= 1'b0;
            sample_valid  <= 1'b0;
            capture_start <= 1'b0;
            triggered     <= 1'b0;
        end
        else begin
            prev_signal  <= trigger_signal;
            sample_valid <= 1'b1;

            capture_start <= 1'b0;

            if (!arm) begin
                triggered <= 1'b0;
            end
            else if (!triggered && condition_met) begin
                capture_start <= 1'b1;
                triggered     <= 1'b1;
            end
        end
    end

endmodule